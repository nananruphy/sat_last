package com.example.akosombotour;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class HotelsFragment extends Fragment {
    ArrayAdapter<String> arrayAdapter;
    ListView listView;
    TextView tvHotels;
    public HotelsFragment (){
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.list_item,container,false);
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        HotelsModel.getUsers(getActivity());
        listView = view.findViewById(R.id.lvUsers);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 0) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 1) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 2) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 3) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 4) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 5) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
            }
        });
        populateUsersList(view);

    }
    private void populateUsersList(View view) {
        // Construct the data source
        ArrayList<HotelsModel> arrayOfUsers = HotelsModel.getUsers(getActivity());
        // Create the adapter to convert the array to views
        HotelsAdapter adapter = new HotelsAdapter(getContext(), arrayOfUsers);
        // Attach the adapter to a ListView
        listView.setAdapter(adapter);
    }
}




