package com.example.akosombotour;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class HistoryFragment extends Fragment {
    ArrayAdapter<String> arrayAdapter;
    ListView listView;
    TextView tvHistory;
    public HistoryFragment(){
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.list_item,container,false);
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        HistoryModel.getUsers(getActivity());
        //populateUsersList(view);
        listView = view.findViewById(R.id.lvUsers);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    Intent intent = new Intent(view.getContext(), AkosomboHistory.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 1) {
                    Intent intent = new Intent(view.getContext(), AkosomboLocation.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 2) {
                    Intent intent = new Intent(view.getContext(), AkosomboChiefs.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 3) {
                    Intent intent = new Intent(view.getContext(), AkosomboClimate.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 4) {
                    Intent intent = new Intent(view.getContext(), AkosomboPopulation.class);
                    view.getContext().startActivity(intent);
                }
            }
        });
        populateUsersList();
    }

    private void populateUsersList() {
        // Construct the data source
        ArrayList<HistoryModel> arrayOfUsers = HistoryModel.getUsers(getActivity());
        // Create the adapter to convert the array to views
        HistoryAdapter adapter = new HistoryAdapter(getContext(), arrayOfUsers);
        // Attach the adapter to a ListView
        listView.setAdapter(adapter);
    }
}